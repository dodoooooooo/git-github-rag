標題：GitHub儲存庫與README
資料類型：官方文件的教學改寫摘要（非網站全文）
來源機關：GitHub 官方文件（docs.github.com）
來源網址：https://docs.github.com/en/repositories/creating-and-managing-repositories/quickstart-for-repositories
教材整理日期：2026-10-25

【內容】
GitHub repository 可存放 Git 專案並設定公開或私人可見性。README.md 常用來介紹專案用途、安裝步驟與使用方式；公開儲存庫不代表內容可任意重製，授權條件仍須查看 LICENSE。新增 GitHub 儲存庫後，可依指引連結本機專案。

【檢索練習問題】
README.md 和 LICENSE 分別有什麼用途？

【提醒】
此為 RAG 教學整理摘要，實際命令行為可能依 Git 版本、設定與儲存庫狀態不同；操作前請核對官方文件。
